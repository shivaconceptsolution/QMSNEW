from pyexpat import model
from django.db import models
class Register(models.Model):
    emailid= models.CharField(max_length=200)
    password= models.CharField(max_length=200)
    mobile= models.CharField(max_length=200)
    fullname= models.CharField(max_length=200)
    def __str__(self):
        return self.emailid + " " + self.password + " "+ self.mobile + " "+ self.fullname 
class Feedback(models.Model):
    feedby = models.CharField(max_length=50)
    feedto = models.CharField(max_length=50) 
    feeddesc = models.CharField(max_length=150)
    feedrate = models.IntegerField()  
    feeddate = models.DateField()
    def __str__(self):
        return self.feedby + " " + self.feedto + " "+ self.feeddesc + " "+ str(self.feedrate)      