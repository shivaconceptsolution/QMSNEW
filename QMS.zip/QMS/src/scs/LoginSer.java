package scs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginSer
 */
@WebServlet("/LoginSer")
public class LoginSer extends HttpServlet {
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/javadb","root","");
			Statement st = conn.createStatement();
			ResultSet x = st.executeQuery("select * from tbl_admin where userid='"+request.getParameter("txtuid")+"' and password='"+request.getParameter("txtpass")+"'");
            if(x.next())
            {
            	response.sendRedirect("admindashboard.jsp");
             //  out.print("login success");
            }
            else
            {
            	out.print("login failed");
            }
            conn.close();
		}
		catch(Exception ex)
		{
			
		}
	}

}
