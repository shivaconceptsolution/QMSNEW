package scs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class FeedbackSer
 */
@WebServlet("/FeedbackSer")
public class FeedbackSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/javadb","root","");
			Statement st = conn.createStatement();
			int x = st.executeUpdate("insert into tbl_feed(name,dept,message,rate) values('"+request.getParameter("txtname")+"','"+request.getParameter("txtdept")+"','"+request.getParameter("txtmessage")+"','"+request.getParameter("txtrate")+"')");
            if(x!=0)
            {
              out.print("Feedback submitted successfully");
            }
            conn.close();
		}
		catch(Exception ex)
		{
			
		}
			
			
		
	}

}
