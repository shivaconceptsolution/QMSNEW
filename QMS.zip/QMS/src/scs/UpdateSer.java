package scs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateSer
 */
@WebServlet("/UpdateSer")
public class UpdateSer extends HttpServlet {
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.
			getConnection("jdbc:mysql://localhost:3306/javadb","root","");
			Statement st = conn.createStatement();
			int x = st.executeUpdate("update tbl_feed set name='"+request.getParameter("txtname")+"',dept='"+request.getParameter("txtdept")+"',message='"+request.getParameter("txtmessage")+"',rate='"+request.getParameter("txtrate")+"' where id='"+request.getParameter("txtid")+"'");
            if(x!=0)
            {
              response.sendRedirect("admindashboard.jsp");
            }
            conn.close();
		}
		catch(Exception ex)
		{
			
		}
	}

}
